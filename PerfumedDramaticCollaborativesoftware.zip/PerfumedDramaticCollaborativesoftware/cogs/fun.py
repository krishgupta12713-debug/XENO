import discord
from discord.ext import commands
from discord import ui
import random, asyncio
from utils.embeds import base_embed

COLOR = 0x2b2d31

# --- RPS View (Same as before) ---
class RPSView(ui.View):
    def __init__(self, author):
        super().__init__(timeout=30)
        self.author = author

    async def play(self, interaction, user_choice):
        bot_choice = random.choice(["rock","paper","scissors"])
        win_map = {"rock":"scissors","paper":"rock","scissors":"paper"}
        if user_choice == bot_choice:
            res = "Tie! 🟰"
        elif win_map[user_choice] == bot_choice:
            res = "You Win! ✅"
        else:
            res = "You Lose! ❌"
        e = base_embed("Rock Paper Scissors", f"You: **{user_choice}**\nBot: **{bot_choice}**\n\n{res}")
        await interaction.response.edit_message(embed=e, view=None)

    @ui.button(label="Rock", emoji="🪨", style=discord.ButtonStyle.secondary)
    async def rock(self, i, b): await self.play(i, "rock")
    @ui.button(label="Paper", emoji="📄", style=discord.ButtonStyle.secondary)
    async def paper(self, i, b): await self.play(i, "paper")
    @ui.button(label="Scissors", emoji="✂️", style=discord.ButtonStyle.secondary)
    async def scissor(self, i, b): await self.play(i, "scissors")

# --- Coinflip IMPROVED - Animated & Beautiful ---
class CoinView(ui.View):
    def __init__(self):
        super().__init__(timeout=30)

    @ui.button(label="Flip Coin", emoji="🪙", style=discord.ButtonStyle.primary)
    async def flip(self, interaction: discord.Interaction, button: ui.Button):
        # Animation Phase
        e1 = base_embed("Coinflip", "Flipping... 🪙\n`[■□□□□]`")
        await interaction.response.edit_message(embed=e1, view=None)
        await asyncio.sleep(0.5)

        e2 = base_embed("Coinflip", "Flipping... 🪙\n`[■■■□□]`\n*The coin is in the air...*")
        await interaction.edit_original_response(embed=e2)
        await asyncio.sleep(0.7)

        result = random.choice(["Heads", "Tails"])
        emoji = "🌟" if result == "Heads" else "🌙"

        e_final = discord.Embed(title=f"{emoji} {result}! {emoji}", description=f"**{interaction.user.display_name}** flipped **{result}**!", color=COLOR, timestamp=discord.utils.utcnow())
        e_final.set_thumbnail(url="https://cdn.discordapp.com/emojis/1094055436510998611.gif" if result=="Heads" else "https://cdn.discordapp.com/emojis/1094055506511118416.gif")
        e_final.set_footer(text="Dhadkhan • Coinflip")

        # Replay button
        new_view = CoinView()
        await interaction.edit_original_response(embed=e_final, view=new_view)

# --- TicTacToe IMPROVED - No Self Play ---
class TicTacToeView(ui.View):
    def __init__(self, p1, p2):
        super().__init__(timeout=120)
        self.board = [""]*9
        self.p1, self.p2 = p1, p2
        self.turn = p1
        self.winner = None

        for i in range(9):
            btn = ui.Button(label="\u200b", style=discord.ButtonStyle.secondary, row=i//3)
            btn.callback = self.make_callback(i)
            self.add_item(btn)

    def make_callback(self, idx):
        async def cb(interaction: discord.Interaction):
            if interaction.user.id not in [self.p1.id, self.p2.id]:
                return await interaction.response.send_message("❌ You are not in this game!", ephemeral=True)
            if interaction.user != self.turn:
                return await interaction.response.send_message(f"❌ It's {self.turn.mention}'s turn!", ephemeral=True)
            if self.board[idx] != "": 
                return await interaction.response.send_message("Already taken!", ephemeral=True)

            self.board[idx] = "X" if self.turn == self.p1 else "O"
            self.children[idx].label = self.board[idx]
            self.children[idx].disabled = True
            self.children[idx].style = discord.ButtonStyle.success if self.board[idx]=="X" else discord.ButtonStyle.danger

            win = self.check_win()
            if win or "" not in self.board:
                for c in self.children: c.disabled = True
                if win:
                    self.winner = self.turn
                    desc = f"🏆 **Winner:** {self.turn.mention} ({self.board[idx]})\n\n{' '.join(self.board[0:3])}\n{' '.join(self.board[3:6])}\n{' '.join(self.board[6:9])}"
                else:
                    desc = f"🟰 **Draw!** No one wins.\n\n{' '.join(self.board[0:3])}\n{' '.join(self.board[3:6])}\n{' '.join(self.board[6:9])}"
                e = base_embed("TicTacToe - Game Over", desc)
                e.color = 0x57F287 if win else 0x2b2d31
                return await interaction.response.edit_message(embed=e, view=self)

            self.turn = self.p2 if self.turn == self.p1 else self.p1
            board_str = "\n".join([f"{' '.join(self.board[i:i+3])}" for i in range(0,9,3)]).replace(""," ")
            e = base_embed("TicTacToe", f"**{self.p1.display_name} (X)** vs **{self.p2.display_name} (O)**\nTurn: {self.turn.mention}\n\n{board_str}".replace('  ',' '))
            # better display
            display = ""
            for i in range(0,9,3):
                row = []
                for j in range(3):
                    val = self.board[i+j]
                    row.append(val if val else "⬜")
                display += "".join(row) + "\n"
            e.description = f"**{self.p1.mention} (X)** vs **{self.p2.mention} (O)**\nTurn: {self.turn.mention}\n\n{display}"
            await interaction.response.edit_message(embed=e, view=self)
        return cb

    def check_win(self):
        wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
        for a,b,c in wins:
            if self.board[a] and self.board[a]==self.board[b]==self.board[c]:
                return True
        return False

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="rps", description="Rock Paper Scissors")
    async def rps(self, ctx):
        await ctx.send(embed=base_embed("RPS", "Choose your move:"), view=RPSView(ctx.author))

    @commands.hybrid_command(name="coinflip", aliases=["flip"], description="Flip a coin - Animated")
    async def coinflip(self, ctx):
        e = base_embed("Coinflip", f"{ctx.author.mention} Click below to flip the coin! 🪙\n\n> Heads or Tails?")
        await ctx.send(embed=e, view=CoinView())

    @commands.hybrid_command(name="avatar", aliases=["av"], description="Show avatar")
    async def avatar(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        e = base_embed(f"{user.display_name}'s Avatar")
        e.set_image(url=user.display_avatar.url)
        view = ui.View()
        view.add_item(ui.Button(label="PNG", url=user.display_avatar.with_format("png").url))
        view.add_item(ui.Button(label="JPG", url=user.display_avatar.with_format("jpg").url))
        view.add_item(ui.Button(label="WEBP", url=user.display_avatar.with_format("webp").url))
        if user.display_avatar.is_animated():
            view.add_item(ui.Button(label="GIF", url=user.display_avatar.with_format("gif").url))
        await ctx.send(embed=e, view=view)

    @commands.hybrid_command(name="tictactoe", aliases=["ox","ttt"], description="Play TicTacToe with someone")
    async def ttt(self, ctx, opponent: discord.Member = None):
        if not opponent:
            return await ctx.send(embed=base_embed("❌ Error","Mention someone to play!\nExample: `/tictactoe @user`"))

        if opponent.id == ctx.author.id:
            return await ctx.send(embed=base_embed("❌ Error","You can't play with yourself! Mention another user."))

        if opponent.bot:
            return await ctx.send(embed=base_embed("❌ Error","You can't play with a bot! Mention a real user."))

        view = TicTacToeView(ctx.author, opponent)
        e = base_embed("TicTacToe", f"**{ctx.author.mention} (X)** vs **{opponent.mention} (O)**\nTurn: {ctx.author.mention}\n\n⬜⬜⬜\n⬜⬜⬜")
        await ctx.send(embed=e, view=view)

async def setup(bot):
    await bot.add_cog(Fun(bot))